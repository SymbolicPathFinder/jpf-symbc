package fuzz.gram.test;


public class ParseException extends RuntimeException {
	ParseException(String message) {
		super(message);
	}
}
